const { LowCodeLambda, DynamoResource, Response } = require('./lib/api.js')

module.exports = { LowCodeLambda, DynamoResource, Response }